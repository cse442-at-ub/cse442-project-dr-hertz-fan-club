<?php

namespace app\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\database\Eloquent\Model;

class Textbook extends Model
{
    use HasFactory;
    public $table="textbook";
}