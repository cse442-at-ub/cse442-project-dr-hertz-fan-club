// Empty JS for your own code to be here
function logout(t) {
    alert("Are you sure?");
}

function double_check(t) {
    var result = confirm(t);
    if (result === true) {
    }
}

